import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']

})
export class DoctorComponent implements OnInit  {

  constructor() { }

  ngOnInit(): void {
  }

  myMap = new Map([
    ["30063", "Marietta"],
    ["30144", "Kennesaw"],
    ["30152", "Kennesaw"],
    ["30062", "Marietta"],
    ["30188", "WoodStock"],
    ["30189", "WoodStock"],
    ["30060", "Marietta"],
    ["30061", "Marietta"]
     
  ]);

 city:any = '';
 Zip = '';

 profileForm = new FormGroup({
  FirstName: new FormControl('', Validators.required),
   LastName: new FormControl('', Validators.required),
   city: new FormControl('', Validators.required),
   State: new FormControl('', Validators.required),
   zipcode: new FormControl('', Validators.required),
  
       });
       onSubmit() {
         //TODO: Use EvenEmitter with form value
         console.warn(this.profileForm.valid);
       }
 

       onBlurMethod(){
         if(this.myMap.get(this.Zip)){ this.city =  this.myMap.get(this.Zip); 
       }
         else{this.city='Not found'}
       }
}

