import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DoctorService } from '../doctor.service';
import {Router} from '@angular/router';
import {ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']

})
export class DoctorComponent implements OnInit  {
 @Input() firstName: string = "";
 @Input() lastName: string = "";
 @Input() gender: string = "";
 @Input() specialty: string = "";
 @Input() education: string = "";
 @Input() emailid: string = "";
 @Input() contactno: string = "";
 @Input() bio: string = "";
 @Input() hospitalname: string = "";
 @Input() street: string = "";
 @Input() city: string = "";
 @Input() state: string = "";
 @Input() zipcode: string = "";
 @Input() availabletime: string = "";
 @Input() website: string = "";

 public mode = 'Add'; //default mode
 private id: any; //student ID

  //initialize the call using StudentService 
constructor(private _myService: DoctorService, private router:Router, public route: ActivatedRoute) { }

ngOnInit(){
  this.route.paramMap.subscribe((paramMap: ParamMap ) => {
      if (paramMap.has('_id'))
          { this.mode = 'Edit'; /*request had a parameter _id */ 
          this.id = paramMap.get('_id');}
      else {this.mode = 'Add';
          this.id = null; }
  });
}

 


 /*profileForm = new FormGroup({
  FirstName: new FormControl('', Validators.required),
   LastName: new FormControl('', Validators.required),
   city: new FormControl('', Validators.required),
   State: new FormControl('', Validators.required),
   zipcode: new FormControl('', Validators.required),
       });*/

       onSubmit(){
        console.log("You submitted: " + this.firstName + " " + this.lastName + " " + this.gender + " " +  this.specialty + " " + this.education + " " + this.emailid + " " + this.contactno + " " + this.bio + " " + this.hospitalname + " " + this.street + " " + this.city + " " + this.state + " " + this.zipcode + " " + this.availabletime + " " + this.website);
        if (this.mode == 'Add')
        this._myService.addDoctors(this.firstName ,this.lastName ,this.gender ,this.specialty ,this.education,this.emailid,this.contactno,this.bio,this.hospitalname,this.street,this.city,this.state,this.zipcode,this.availabletime,this.website);
        if (this.mode == 'Edit')
    this._myService.updateDoctors(this.id,this.firstName ,this.lastName ,this.gender ,this.specialty ,this.education,this.emailid,this.contactno,this.bio,this.hospitalname,this.street,this.city,this.state,this.zipcode,this.availabletime,this.website);
        this.router.navigate(['/listDoctors']);
      }

       
}

