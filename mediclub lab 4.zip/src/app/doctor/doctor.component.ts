import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { DoctorService } from '../doctor.service'
@Component({
  selector: 'app-doctor',
  templateUrl: './doctor.component.html',
  styleUrls: ['./doctor.component.css']

})
export class DoctorComponent implements OnInit  {
 @Input() firstName: string = "";
 @Input() lastName: string = "";
 @Input() gender: string = "";
 @Input() specialty: string = "";
 @Input() education: string = "";
 @Input() emailid: string = "";
 @Input() contactno: string = "";
 @Input() bio: string = "";
 @Input() hospitalname: string = "";
 @Input() street: string = "";
 @Input() city: string = "";
 @Input() state: string = "";
 @Input() zipcode: string = "";
 @Input() availabletime: string = "";
 @Input() website: string = "";

  //initialize the call using StudentService 
constructor(private _myService: DoctorService) { }

  ngOnInit(): void {
  }

 


 /*profileForm = new FormGroup({
  FirstName: new FormControl('', Validators.required),
   LastName: new FormControl('', Validators.required),
   city: new FormControl('', Validators.required),
   State: new FormControl('', Validators.required),
   zipcode: new FormControl('', Validators.required),
       });*/

       onSubmit(){
        console.log("You submitted: " + this.firstName + " " + this.lastName + " " + this.gender + " " + " " + this.specialty + " " + this.education + " " + this.emailid + " " + this.contactno + " " + this.bio + " " + this.hospitalname + " " + this.street + " " + this.city + " " + this.state + " " + this.zipcode + " " + this.availabletime + " " + this.website);
        this._myService.addDoctors(this.firstName ,this.lastName);
    }

       
}

